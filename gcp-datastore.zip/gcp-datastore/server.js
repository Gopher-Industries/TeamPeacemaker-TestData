/**
 * Node js app for app engine
 */
const express = require('express')
const app = express();

// Import Datastore
const {Datastore} = require('@google-cloud/datastore');

// Creates a client
const datastore = new Datastore();

const entities = [
    'medication_script',
    'medicine_information',
    'user',
    'user_medication',
    'reward_catalogue',
];

/**
 * 
 * @param {String} kind 
 * @returns {Object}
 */
async function runQuery(kind) {
    const query = datastore.createQuery(kind);
    const [results] = await datastore.runQuery(query);
    return results;
}

/**
 * Appends an array or records to the datastore
 * @param {String} kind 
 * @param {Array} data 
 */
async function addToEntity(kind, data) {
    data.forEach(async (item) => {
        const key = datastore.key(kind);
        const entity = {
            key: key,
            data: item,
        };
        await datastore.save(entity);
    });
}

/**
 * Clears all records from the datastore
 */
async function clearDatastore() {
    entities.forEach(async (kind) => {
        const query = datastore.createQuery(kind);
        const [results] = await datastore.runQuery(query);
        results.forEach(async (item) => {
            await datastore.delete(item[datastore.KEY]);
        });
    });
}


app.get('/add-random', async (req, res) => {
  entities.forEach(async (entity) => {
    const randomData = require(`./random/${entity}.json`);
    if (entity === 'user_medication') {
     // Select a random user and add the medication to their list
        const users = await runQuery('user');
        for (let i = 0; i < randomData.length; i++) {
            const randomUser = users[Math.floor(Math.random() * users.length)];
            randomData[i].user_id_fk = randomUser[datastore.KEY].id;
        }
    }
    await addToEntity(entity, randomData);
  });
    res.send('\
    <h1>Added random data</h1> \
    <ul> \
        <li><a href="/clear">Clear datastore</a></li> \
        <li><a href="/">Query datastore</a></li> \
    </ul>'
    );
});

app.get('/clear', async (req, res) => {
    await clearDatastore();
    res.send('<h2>Cleared datastore</h2>\
    <ul> \
        <li><a href="/add-random">Add random data</a></li> \
        <li><a href="/">Query datastore</a></li> \
        </ul>'
    );
});


app.get('/',async (req,res)=>{
    let data = {};
    for (let i = 0; i < entities.length; i++) {
        data[entities[i]] = await runQuery(entities[i]);
    }
    res.json(data);
})

const PORT = process.env.PORT || 8080;


app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});